package com.yaarwin.app;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);

        View logo = findViewById(R.id.logo_container);
        TextView title = findViewById(R.id.tv_title);
        TextView tagline = findViewById(R.id.tv_tagline);
        TextView status = findViewById(R.id.tv_status);
        View bar = findViewById(R.id.progress_bar);

        logo.setAlpha(0f); title.setAlpha(0f); tagline.setAlpha(0f);
        status.setAlpha(0f); bar.setScaleX(0f); bar.setPivotX(0f);

        AnimatorSet set = new AnimatorSet();
        set.playTogether(
            a(logo,"alpha",0f,1f,800,300), a(logo,"scaleX",0.5f,1f,800,300), a(logo,"scaleY",0.5f,1f,800,300),
            a(title,"alpha",0f,1f,600,900), a(title,"translationY",40f,0f,600,900),
            a(tagline,"alpha",0f,1f,600,1200),
            a(status,"alpha",0f,1f,400,1600),
            a(bar,"scaleX",0f,1f,1500,1700)
        );
        set.start();

        Handler h = new Handler(Looper.getMainLooper());
        h.postDelayed(() -> status.setText("Verifying invitation code..."), 2000);
        h.postDelayed(() -> status.setText("Access granted. Welcome!"), 2900);
        h.postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            finish();
        }, 3500);
    }

    private ObjectAnimator a(View v, String p, float from, float to, long dur, long delay) {
        ObjectAnimator oa = ObjectAnimator.ofFloat(v, p, from, to);
        oa.setDuration(dur); oa.setStartDelay(delay);
        oa.setInterpolator(new AccelerateDecelerateInterpolator());
        return oa;
    }
}
